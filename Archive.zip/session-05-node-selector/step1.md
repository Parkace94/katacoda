>It's going to take few minutes to have kubernetes to start.

### About Node Selector:
- nodeSelector is the simplest recommended form of node selection constraints.
- For the pod to be eligible to run on a node, the node must have matching labels.